package ds.edu.project4task2;

import com.google.gson.Gson;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.*;
import java.net.*;
import Model.*;

/*
* Name: Jerry Huang
* ID: jerryh
*
* */

/*
* What does MainActivity does?
* 1. Send the request to servlet to get the news info
* 2. Generate the request from user's prompt
*
* */
public class MainActivity extends AppCompatActivity {
    //Variable for UI design
    EditText inputEditText;
    Button sendButton;
    TextView responseTextView;

    // servlet URL for communication
    String servletUrl = "https://supreme-yodel-p4wpv5rv7g43rjqp-8080.app.github.dev/messages";

    /*
    * Build up the UI of mobile APP
    * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Call the superclass method to perform system-level setup for the activity
        super.onCreate(savedInstanceState);

        // Set the layout of this activity to activity_main.xml
        setContentView(R.layout.activity_main);

        // Get references to the views defined in activity_main.xml by their IDs
        // User input field
        inputEditText = findViewById(R.id.inputEditText);
        // Button to send input
        sendButton = findViewById(R.id.sendButton);
        // TextView to show response or messages
        responseTextView = findViewById(R.id.responseTextView);

        // Set a click listener for the "Send" button
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the trimmed text entered by the user
                String userInput = inputEditText.getText().toString().trim();
                // Check if input is not empty
                if (!userInput.isEmpty()) {
                    // Show a "loading" message while waiting for the server
                    responseTextView.setText("⏳ Please wait, connecting to server...");
                    // Use a Handler to simulate a 2-second delay before sending the message
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // Call the method to send the input to the servlet
                            sendMessageToServlet(userInput);
                        }
                    }, 2000); // 2000ms = 2 seconds delay

                } else {
                    // If the input field is empty, prompt the user to enter a keyword
                    responseTextView.setText("Please enter a keyword.");
                }
            }
        });

    }
    //Send the request to server
    //Get the response from server
    private void sendMessageToServlet(String keyword) {
        // Start a new background thread for network operations (to avoid blocking the UI)
        new Thread(() -> {
            try {
                // Create a URL object pointing to the servlet endpoint
                URL url = new URL(servletUrl);
                // Open an HTTP connection to the servlet
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // Set the request method to POST
                conn.setRequestMethod("POST");
                // Indicate the content type being sent is JSON
                conn.setRequestProperty("Content-Type", "application/json");
                // Enable output so we can send data to the server
                conn.setDoOutput(true);

                // Get device model information for the request payload
                String model = Build.MODEL;
                String manufacturer = Build.MANUFACTURER;
                String deviceModel = manufacturer +" "+ model;
                // Create JSON request
                Gson gson = new Gson();

                //JSON format
                String jsonRequest = gson.toJson(new RequestMessage("search", keyword, deviceModel));

                // Send to servlet
                OutputStream os = conn.getOutputStream();
                // Write JSON string as bytes
                os.write(jsonRequest.getBytes());
                // Ensure everything is sent
                os.flush();
                // Close the stream
                os.close();

                // Handle response code and stream
                int responseCode = conn.getResponseCode();
                // Decide which stream to read: input for success, error stream for failure
                InputStream inputStream = (responseCode >= 200 && responseCode < 300)
                        ? conn.getInputStream()
                        : conn.getErrorStream();

                // Read the response from the server line by line
                BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line).append("\n");
                }
                // Close the reader
                in.close();

                // If the response code indicates success
                if (responseCode >= 200 && responseCode < 300) {
                    // Convert the JSON response string into a ResponseMessage object
                    String jsonResponse = response.toString();
                    ResponseMessage responseMessage = gson.fromJson(jsonResponse, ResponseMessage.class);

                    // Prepare a formatted string to display the news info
                    StringBuilder newsInfo = new StringBuilder();
                    // If the response status is "success"
                    if ("success".equalsIgnoreCase(responseMessage.getStatus())) {
                        newsInfo.append("✅ Status: ").append(responseMessage.getStatus()).append("\n\n");
                        newsInfo.append("📰 Title: ").append(responseMessage.getTile()).append("\n\n");
                        newsInfo.append("🔗 Link: ").append(responseMessage.getLink()).append("\n\n");
                        newsInfo.append("📝 Description: ").append(responseMessage.getDescription()).append("\n\n");
                        newsInfo.append("📅 Published: ").append(responseMessage.getPubDate()).append("\n\n");
                        newsInfo.append("🌐 Language: ").append(responseMessage.getLanguage()).append("\n\n");
                        // Add creator info if available
                        if (responseMessage.getCreator() != null && !responseMessage.getCreator().isEmpty()) {
                            newsInfo.append("✍️ Creator: ").append(String.join(", ", responseMessage.getCreator())).append("\n\n");
                        }
                        // Add country info if available
                        if (responseMessage.getCountry() != null && !responseMessage.getCountry().isEmpty()) {
                            newsInfo.append("🌍 Country: ").append(String.join(", ", responseMessage.getCountry())).append("\n");
                        }
                    } else {
                        // If the status is not "success", show the failure message
                        newsInfo.append("❌ Status: ").append(responseMessage.getStatus()).append("\n\n");
                    }

                    // Update the UI with the result using runOnUiThread
                    runOnUiThread(() -> {
                        responseTextView.setText(newsInfo.toString());
                    });

                } else {
                    // If the response code is an error, show server error message
                    runOnUiThread(() -> responseTextView.setText(
                            "❌ Server Error (" + responseCode + "):\n" + response.toString()));
                }

            } catch (Exception e) {
                // If an exception occurs (network failure, JSON parsing, etc.), print the stack trace
                e.printStackTrace();
                // Update the UI to show the error message
                runOnUiThread(() -> responseTextView.setText("❌ Error: " + e.getMessage()));
            }
        }).start();
    }

}
