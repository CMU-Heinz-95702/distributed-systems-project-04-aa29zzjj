package Model;
/*
* Name: Jerry Huang
* ID: jerryh
* */

//Client's request message
public class RequestMessage {
    private String request;
    private String keyWord;
    private String deviceModel;

    //Default Constructor
    public RequestMessage(){
        this.request = "";
        this.keyWord = "";
        this.deviceModel = "";
    }
    //Constructor
    public RequestMessage(String request, String keyWord, String deviceModel) {
        this.request = request;
        this.keyWord = keyWord;
        this.deviceModel = deviceModel;
    }


}
