package Model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
/*
* Name: Jerry Huang
* ID: jerryh
* */

//User for generate the response
public class ResponseMessage {
    private String status;
    private String tile;
    private String link;
    private String description;
    private String pubDate;
    private String language;
    private List<String> creator;
    private List<String> country;

    //Default Constructor
    public ResponseMessage() {
        this.status = "";
        this.tile = "";
        this.link = "";
        this.description = "";
        this.pubDate = "";
        this.language = "";
        this.creator = new ArrayList<String>();
        this.country = new ArrayList<String>();
    }
    //Constructor for fail search
    public ResponseMessage(String status) {
        this.status = status;
    }
    //Constructor
    public ResponseMessage(String status, String tile, String link, String description, String pubDate, String language,List<String> creator, List<String> country) {
        this.status = status;
        this.tile = tile;
        this.link = link;
        this.description = description;
        this.pubDate = pubDate;
        this.language = language;
        this.creator = creator;
        this.country = country;
    }

    //Getter
    public String getStatus() {
        return status;
    }
    //Get the data from API Key

    public String getTile() {
        return tile;
    }

    public String getLink() {
        return link;
    }

    public String getDescription() {
        return description;
    }

    public String getPubDate() {
        return pubDate;
    }

    public String getLanguage() {
        return language;
    }

    public List<String> getCreator() {
        return creator;
    }

    public List<String> getCountry() {
        return country;
    }

}
